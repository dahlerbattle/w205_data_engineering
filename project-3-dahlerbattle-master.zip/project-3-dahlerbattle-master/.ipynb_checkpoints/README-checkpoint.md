# Project 3: Understanding User Behavior

### Context
We are data scientists at a game development company and are trying to build a data pipeline for interesting events in our game. Our latest mobile game has three events we're interested in tracking: `buy a sword`,`join guild`, and `win_victory_points`. Each of these events have metadata characterstics attached (i.e. sword type,  of such events (i.e., sword type, guild name, victory point color, etc)

### Key business questions
Our key business questions are the following: 
1. How many unique players play in one day, i..e, what is our Daily Active Usage (DAU)?
2. Which are the top 3 most popular 'sword types', purchased by players?
3. Which are the top 3 most popular 'guilds' joined by players?
4. Which victory point colors were obtained the most between gold, silver, and bronze? 
6. Who is the longest gameplayer? 

### Key events
Each of these events have sub-events that we will track throughout the game, developed in our original API. 
1. purchase_a_sword() <player purchases swords> 
    - sword_type: Generated at random from a variety of options
    - sword_level: Generated at random from 1-100
    - timestamp
2. join_guild() <player joins a guild>
    - guild_type: Generated at random from a variety of options
    - guild_strenth: Generated at random from 1-100
    - timestamp
3. victory_points() <player obtains victory points in the game>
    - victory_point_color: Generated at random between gold, silver, and bronze
    - location: Generated at random from a variety of options
    - timestamp
    

### This folder includes the following materials used to run the project
    1. 'docker-compose.yml' - A .yml file to spin up containers needed for streaming data into the game and querying results. 
    2. 'game_api.py' - A game API that helps feed data into the system. 
    3. 'write_stream.py' - Helps convert our API into a streaming context. Takes data and prepares it for parquet. 
    4. 'dahler-battle-project3.pynb' - A notebook to show our process and results. 