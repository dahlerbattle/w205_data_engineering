#!/usr/bin/env python

# Flask Documentation  -  https://flask.palletsprojects.com/en/1.1.x/quickstart/
# python-kafka documentation  -  https://flask.palletsprojects.com/en/1.1.x/quickstart/

import json
from kafka import KafkaProducer
from flask import Flask, request
import random 

app = Flask(__name__)
producer = KafkaProducer(bootstrap_servers='kafka:29092')

def log_to_kafka(topic, event):
    event.update(request.headers)
    producer.send(topic, json.dumps(event).encode())

@app.route("/")
def default_response():
    default_event = {'event_type': 'default'}
    log_to_kafka('events', default_event)
    return "This is the default response!\n"

@app.route("/purchase_a_sword")
def purchase_a_sword():
    swordtypes = ["lightsaber", "rapier", "katana", "short_sword", "long_sword", "gladius", "dao", "walking_cane"]
    purchase_sword_event = {'event_type': 'purchase_sword',
                           'sword_type': random.choice(swordtypes),
                           'sword_level': str(random.randint(1,100))}
    log_to_kafka('events', purchase_sword_event)
    return "Sword Purchased!\n"

@app.route("/join_guild")
def join_guild():
    guildtypes = ["gnome", "satyr", "martian", "human", "minotaur", "faun", "oger", "cyclopse", "python", "boar"]
    jg_event = {'event_type': 'join_guild',
                'guild_type': random.choice(guildtypes),
                'guild_strength': str(random.randint(1,100))}
    log_to_kafka('events', jg_event)
    return "Guild Joined!\n"

@app.route("/win_victory_points")
def win_victory_points():
    colors = ["gold", "bronze", "silver"]
    locations = ["drawbridge", "castle", "dungeon", "tower", "field", "archery_range", "woods", "harbor", "courtyard", "dining_hall"]
    wvp_event = {'event_type': 'win_victory_points',
                'victory_point_color': random.choice(colors),
                'location': random.choice(locations)}
    log_to_kafka('events', wvp_event)
    return "Victory Point Won!\n"