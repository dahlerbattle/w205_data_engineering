# Project 2: Tracking User Activity

#### By: Dahler Battle, Section 6



##### Project Overview

In this assignment, education technology providers are interested in using your assessment service to publish their tests and other related services on your platform. In order to accomplish this goal, we must build a simple data infrastructure to land the data in the form and structure it needs to be to be queried by a customer's data science team. 



##### The Infastructure

###### Overview

Initially, we were only given the dataset through a curl command below. 

```
curl -L -o assessment-attempts-20180128-121051-nested.json https://goo.gl/ME6hjp
```

We utilized three primary services to publish, consume, and transform this data through messages so that it can be analyzed and  queried at a future date. First, we utilized Kafka to initially publish and consume messages. We then took thosee Kafka messages and used Spark to transform the data messages into a structure that we would like to use for queries. We then landed that data into a Hadoop Files System and used PySpark to query for some simple business questions. 

The steps below outline the steps I took in building out the data pipeline. I only included the most impoortant keys in the process. For further review, please check the history file. 

###### Step I: Setting Up Kafka

Kafka is perhaps the critical piece in the data infrastructure as it allows topics to be taken from the underlying data to the spark and Hadoop. In order to accomplish this, we spun up our .yml file through docker. This spun up individual containers for us to pass arguments through Kafka and a configuration service called zookeeper. We then validated their logs to make sure they were running properly. 

```bash
docker-compose ps 
docker-compose logs kafka | grep -i started
docker-compose logs zookeeper | grep -i binding
```

We then created a topic in Kafka called "assessments" and kafkatcat to pass messages through the *commits* topic. This will be important as it will store our dataset and eventually publish it to Spark and HDFS. I then validated that this was created by producing messages through kafkacat to the assessment's topic. Also notice that is calling Zookeeper through the port 32181. The "messages" created were in fact the information from our json file. This data  is now ready to be passed into Spark.

```bash
docker-compose exec kafka \
  kafka-topics \
    --create \
    --topic commits \
    --partitions 1 \
    --replication-factor 1 \
    --if-not-exists \
    --zookeeper zookeeper:32181

docker-compose exec mids \
  bash -c "cat /w205/project-2-dahlerbattle/assessment-attempts-20180128-121051-nested.json  \
    | jq '.[]' -c \
    | kafkacat -P -b kafka:29092 -t commits"
```

###### Step II: Transform Data In Spark

We then use Pyspark to spin up the spark container (this was created earlier through the same .yml and docker). In order to use the data from Kafka we have to read it through the Kafka topic created earlier. This command  reads in Kafka through its port (29092) and takes out the *commits* topic in the third line.

```python
raw_assessments = spark \
  .read \
  .format("kafka") \
  .option("kafka.bootstrap.servers", "kafka:29092") \
  .option("subscribe","commits") \
  .option("startingOffsets", "earliest") \
  .option("endingOffsets", "latest") \
  .load() 
```

Now that it is in Spark we can do some exploratory data analysis, print the schema, drop or add variables, and transform the data to answer the business questions below ( please refer to the "Critical Business Questions" for more info). Some example commands of this are seen below. 

*Note that dropping variables from data is not neccesarily advised, however for  the purposes of this project it can be used to show that data can be transformed and that transformed data can go to a HDFS.* 

```python
#show schema
raw_assessments.printSchema()

#create new dataset that casts the json file into strings and ommits unused variables 
assessments = raw_assessments.select(raw_assessments.value.cast('string'))
extracted_assessments = assessments.rdd.map(lambda x: json.loads(x.value)).toDF()
extracted_assessments = extracted_assessments.drop("certification", "user_exam_id", "keen_id", "keen_timestamp", "keen_created_at")
```

###### Step II: Transform Data In Spark

Lastly we can take our raw and/or transformed data and store it in a Hadoop File System. We can also save a Spark SQL query into Hadoop as well. Hadoop is a distributed storage network that will help us store utilize data at a future date for further analysis. In order to do this we simply wrote it into the system and searched it using Cloudera via Docker (also configured in the .yml file from earlier). 

```python
#writing the original dataset to hdfs
assessments.write.parquet("/tmp/assessments")
assessments.write.parquet("/tmp/extracted_assessments")

#writing a dataset to hdf that has been queried by SparkSQL
extracted_assessments.registerTempTable('assess')
spark.sql("select exam_name, max_attempts, sequences, started_at from assess limit 10").show()
assessment_info = spark.sql("select exam_name, max_attempts, sequences, started_at from assess limit 10")
assessment_info.write.parquet("/tmp/assessment_info")
```

```bash
#check the results
docker-compose exec cloudera hadoop fs -ls /tmp/
docker-compose exec cloudera hadoop fs -ls /tmp/assessments/

---------------------------------------------------------------------------------------------------------------
Found 6 items
drwxr-xr-x   - root   supergroup          0 2020-07-11 14:55 /tmp/assessment_info
drwxr-xr-x   - root   supergroup          0 2020-07-11 14:03 /tmp/assessments
drwxr-xr-x   - root   supergroup          0 2020-07-11 14:49 /tmp/commits
drwxr-xr-x   - root   supergroup          0 2020-07-10 22:02 /tmp/extracted_assessments
drwxrwxrwt   - mapred mapred              0 2018-02-06 18:27 /tmp/hadoop-yarn
drwx-wx-wx   - root   supergroup          0 2020-07-10 21:55 /tmp/hive
```



##### The Data

The data comes from the curl command in the *project_2* folder and arrives in Kafka through a nested JSON file. After extracting the relevant datafields in PySpark, exploring the schema and general dataframe in spark and in Python, we have a much fuller understanding of the data. 

```python
extracted_assessments.show()
```

```python
import json
import pprint

f = open("assessment-attempts-20180128-121051-nested.json","r")
f = f.read()
json_data = json.loads(f)
p.pprint(json_data[0])
```

After review, we see that this dataset comes from a Keen test-taking service, which is an online test taking service that provides the testing infastructure for O'Reilly tests. Each column is a set of things that that are being processed at an inidividual test taking level. It contains columns such as certification number, the exam name,, when it was started, the test taker's id, etc. The most important (and most difficult) aspect of this dataset to note is the nested dictionaries within the 'sequences' column. This column contains critical information such as the test-takers final scores and goes into the answers that they provided for each question. These nested dictionaries must be properly parsed in order to dive into further analysis. 

While this information is important to have, it is essentially metadata for each individual test, it does not go into a level of granularity required to answer some really important questions. This dataset for example does not include information on how much time people spent on each question or which questions were skipped and reviewed later. Therefore it may be worth exploring trying to find this data so that data scientists can understand the most difficult or time intensive questions for each test and better understand a user's testing process. 



##### Critical Business Questions

Now that we have a better grasp of the dataset, it is time to answer some critical business questions. My analysis answered five primary business questions. However, the first two summary questions were able to answer two questions each. The last question was devised on my own and required some additional data manipulation. Thus I split my analysis and code into three parts. 

Since this dataset provides data on higher level test logs instead of more granular question logs, I decided to focus my analysis on higher scale problems such as an exploratory analysis, an understanding of the different tests provided, and the timing around when people took tests. I made certain assumptions about the data that should also be noted: 1) I did not use the keen specific data and I assumed that data science teams at other companies would not have dynamic access to cross reference this data with other sources. As such, I left it out of the analysis. 

These questions were each answered through Spark using PySpark. Please refer to the Spark history file to have a better understanding of my data manipulations, my Hadoop dataframe, and the business question queries below. 

###### Questions, Part 1: 

My first question is a two part question and is aimed at providing a better high level analysis of the dataset. The first question asks how many individual tests were taken in the keen dataset. The second part asks, "what is the date range for the tests in the Keen dataset". This can help give us an appropriate framing for the dataset, by giving us an idea of the overall number of tests and the season(s) for which they were taken.This can be accomplished with a simple describe function grouped by the *started_at* variable. 

```python
extracted_assessments.groupBy("started_at").count().describe().show()
```

This high level analysis shows that there were 3,242 individual tests taken in the dataset. Additionally, these tests were taken from November 21, 2017 to January 28, 2018. With the assumption that test-taking is likely seasonal, one could conservatively approximate that 18,000 tests were taken during the 2017-2018 academic calendar. 

###### Questions, Part II:

The second series of questions asks, how many different tests are in the dataset? It additionally asks which test was taken the most in this timeframe and which test was taken the least? This question is important as it allows edtech companies like Pearson to understand which tests to focus their energy on, and which topics they should develop in the future to accommodate demand. 

```python
extracted_assessments.groupBy("exam_name").count().describe().show()

#most popular tests
extracted_assessments.groupBy("exam_name").count().orderBy('count', ascending=False).show(truncate = False)

#least popular tests
extracted_assessments.groupBy("exam_name").count().orderBy('count', ascending=True).show(truncate = False)
```

This command helped answer both parts of this question. First, we find out that there were 103 different types of textbook tests  taken during this time period. The most popular tests were *Learning Git,* *Introduction to Python*, *Introduction to Java 8*, and *Intermediate Python Programming*, which were taken 394, 162, 158, and 158 times respectively. The describe function above also shares that several book titles only had one tests taken each. These were *Native Web Apps for Android*, *Operating Red Hat Enterprise Linux Servers*, *Learning to Visualize Data with D3.js*, and *Nulls, Nulls, Three-valued Logic and Missing Information*. From this data, Pearson could spend more of its time and resources improving questions for the tests most taken and less time on the more unpopular titles. The following queries are made under the assumption that all tests were at least attempted (and not just pulled up and exited). 

###### Question, Part III:

Finally, it is important to take a look at the times in which students took the tests. This could help education companies better understand the habits of their test-takers and could also inform them of when to schedule tests at their in-person testing centers. 

In order to appropriately address this question, I took the *started_at* column, grabbed the information in the hour section, and created a new variable with this information. This analysis requires the assumption that tests were started at that hour and were not pulled up and returned to at a later time. In order to find the hour column, I had to utilize Python's sys package. 

```python
from pyspark.sql.functions import hour

#created new column to track the hour
extracted_assessments = extracted_assessments.withColumn('hour', hour("started_at"))
                                                         
#found the hours tests were taking, going from most to least popular
extracted_assessments.groupBy("hour").count().orderBy('count', ascending=False).show(25)
```

This data showed that the most popular test times, in order were 2pm, 1pm, and 3pm respectively. Additionally, as expected the least popular times starting with the worst were to be expected with the least popular being 2am, with 3am and midnight to follow. It should be noted that early morning start times such as 8am or 9am were within the bottom half of the list. These are popular test taking times for in-person examinations such as for the GRE or GMAT and could potentially be revised based on this data. This information could be additionally taken out of the dataset and delivered as a histogram in Python to provide a fuller picture of the data. 


##### Summary
In this project, we were tasked with building a data pipeline to track test assessments for education technology companies such as McGraw Hill. During the project, we built a data infrastructure to land JSON data through Kafka, perform queries on it through Spark, and save the databases in HDFS for further querying. During the project, we also answered key business decisions that could be helpful for an analytics team. First we answered some descriptive questions about the dataset, finding over 3200 test over three month period from November 2017 to January 2018. We then found that the most popular tests were Learning Git, Intro to Java 8, and tests from two Python related book series. Lastly we extracted the hour each test was taken from the DATETIME column and added this info an additional column to the dataset to find the most and least popular hours to take the tests. This revised dataset was then saved into the HDFS for future querying by our colleagues at the Edtech firms. 

*NOTE: I spent considerable amount of time trying to parse the JSON file, but was not able to pull out a key variable that I wanted 'sequences'['counts' == 'all correct']. Given additional time, I would have liked to answer another business question around which test had the highest number of perfect scores.* 