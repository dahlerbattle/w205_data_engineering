# Project 2: Tracking User Activity

## Structure

For simplicity sake, all of the files needed will just be in the main project 2 folder. 

These files include the following: 


The following items are included in the main project-2-dahlerbattle folder:

1. A markdown format report (project_2_report_dahler_battle)
    This guides you through the steps I took in the project. This includes code fences for the most 
    important code in the document. I included every function that I thought was critical to the 
    overall structure of the data pipeline, but may have omitted 2-3 others. For a full reference of 
    each command/step I took, please refer to the Spark history file. 
    
2. A primary docker-compose.yml file
    This has everything needed to spin up zookeeper, kafka, cloudera, and spark. 
    
3. A command line history file (dahler_battle-history.txt) 
    This describes my command line history. This is required by the project guidelines. I would like 
    to warn you that this file is very messy, but the key components should be found at the very end 
    of the document. 
   
    
The history files are included in a further folder entitled, spark-with-kafka-and-hdfs
    
1. A spark history file (dahler_battle-spark_history.txt)
    This outlines the steps to import data into spark, run some queries, and send this pipeline to 
    HDFS for later use. This should be used as a supplement to my written report. 
    
    